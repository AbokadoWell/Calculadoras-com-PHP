<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="./style.css">
    <title>Calculadora</title>
</head>
<body>
    <h1>Calculadora</h1>
    <ul>
        <li><a href="./calculadoras/botoes.php">Botões</a></li>
        <li><a href="./calculadoras/opcoes.php">Opções</a></li>
        <li><a href="./calculadoras/checkbox.php">Checkbox</a></li>
    </ul>

</body>
</html>